#define NEX_RET_CMD_FINISHED                (0x01)
#define NEX_RET_EVENT_TOUCH_HEAD            (0x65)
#define NEX_EVENT_POP                       (0x00)
#define NEX_RET_STRING_HEAD                 (0x70)
#define NEX_RET_NUMBER_HEAD                 (0x71)

char buffer[30] = {0};

boolean forceRefresh = false;
#define CMD_SET_HOUR  0
#define CMD_PARENTH     1
#define CMD_BO_SET_PIC  2
#define CMD_BO_SET_PIC2 3
#define CMD_BO_SET_ALT_PIC2 4
#define CMD_BO_SET_ALT_PIC 5
#define CMD_BO_REFRESH 6
#define CMD_BA_SET_PIC 7
#define CMD_BA_SET_PIC2 8
#define CMD_BA_SET_ALT_PIC2 9
#define CMD_BA_SET_ALT_PIC 10
#define CMD_BA_REFRESH 11
#define CMD_BN_SET_PIC 12
#define CMD_BN_SET_PIC2 13
#define CMD_BN_SET_ALT_PIC2 14
#define CMD_BN_SET_ALT_PIC 15
#define CMD_BN_REFRESH 16
#define CMD_SET_L1 17
#define CMD_SET_L2 18
#define CMD_SET_L3 19
#define CMD_SET_L4 20
#define CMD_SET_L5 21
#define CMD_SET_L6 22
#define CMD_SET_WT 23
#define CMD_SET_WF 24
#define CMD_SET_LT 25
#define CMD_SET_LF 26
#define CMD_INIT1 27
#define CMD_INIT2  28
#define CMD_SET_PAGE 29
#define CMD_SET_T1 30
#define CMD_SET_T2 31
#define CMD_SET_T3 32
#define CMD_SET_T4 33
#define CMD_SET_T5  34
#define CMD_SET_T6  35
#define CMD_SET_T7  36
#define CMD_SET_T8  47
#define CMD_SET_T9  48
#define CMD_SET_T10  49
#define CMD_GET_T1 37
#define CMD_GET_T2 38
#define CMD_GET_T3 39
#define CMD_GET_T4 40
#define CMD_GET_T5 41
#define CMD_GET_T6 42
#define CMD_GET_T7 43
#define CMD_GET_T8 44
#define CMD_GET_T9 45
#define CMD_GET_T10 46

#define STR_ON 0
#define STR_OFF 1
#define STR_NIGHT 2
#define STR_SUNRISE 3
#define STR_SUNSET 4
#define STR_DASH 5

#define PAGE_HOME 0
#define PAGE_CONFIG 1
#define PAGE_SETTIME 2
#define PAGE_SETTINGS 3
#define PAGE_PWM 4
#define PAGE_TEST 5

char const xbopic[] PROGMEM = "bo.pic=3";
char const xbopic2[] PROGMEM = "bo.pic=3";
char const xbo2pic[] PROGMEM = "bo.pic=2";
char const xbo2pic2[] PROGMEM = "bo.pic=2";
char const xboref[] PROGMEM = "ref bo";
char const xbapic[] PROGMEM = "ba.pic=6";
char const xbapic2[] PROGMEM = "ba.pic=6";
char const xba2pic[] PROGMEM = "ba.pic=7";
char const xba2pic2[] PROGMEM = "ba.pic=7";
char const xbaref[] PROGMEM = "ref ba";
char const xbnpic[] PROGMEM = "bn.pic=4";
char const xbnpic2[] PROGMEM = "bn.pic=4";
char const xbn2pic[] PROGMEM = "bn.pic=5";
char const xbn2pic2[] PROGMEM = "bn.pic=5";
char const xbnref[] PROGMEM = "ref bn";
char const xl1[] PROGMEM = "l1.txt=\"";
char const xl2[] PROGMEM = "l2.txt=\"";
char const xl3[] PROGMEM = "l3.txt=\"";
char const xl4[] PROGMEM = "l4.txt=\"";
char const xl5[] PROGMEM = "l5.txt=\"";
char const xl6[] PROGMEM = "l6.txt=\"";
char const xpth[] PROGMEM = "\"";
char const xwt[] PROGMEM = "wt.txt=\"";
char const xlt[] PROGMEM = "lt.txt=\"";
char const xwf[] PROGMEM = "wf.txt=\"";
char const xlf[] PROGMEM = "lf.txt=\"";
char const init1[] PROGMEM = "bkcmd=0";
char const init2[] PROGMEM = "page 0";
char const xpage[] PROGMEM = "page ";
char const xt1[] PROGMEM = "t1.txt=\"";
char const xt2[] PROGMEM = "t2.txt=\"";
char const xt3[] PROGMEM = "t3.txt=\"";
char const xt4[] PROGMEM = "t4.txt=\"";
char const xt5[] PROGMEM = "t5.txt=\"";
char const xt6[] PROGMEM = "t6.txt=\"";
char const xt7[] PROGMEM = "t7.txt=\"";
char const xt8[] PROGMEM = "t8.txt=\"";
char const xt9[] PROGMEM = "t9.txt=\"";
char const xt10[] PROGMEM = "t10.txt=\"";
char const xgt1[] PROGMEM = "get t1.txt";
char const xgt2[] PROGMEM = "get t2.txt";
char const xgt3[] PROGMEM = "get t3.txt";
char const xgt4[] PROGMEM = "get t4.txt";
char const xgt5[] PROGMEM = "get t5.txt";
char const xgt6[] PROGMEM = "get t6.txt";
char const xgt7[] PROGMEM = "get t7.txt";
char const xgt8[] PROGMEM = "get t8.txt";
char const xgt9[] PROGMEM = "get t9.txt";
char const xgt10[] PROGMEM = "get t10.txt";

char const xhoursettext[] PROGMEM = "hour.txt=\"";

PGM_P const nxStrings[] PROGMEM
{
  xhoursettext, //0
  xpth, //1
  xbopic, //2
  xbopic2, //3
  xbo2pic2, //4
  xbo2pic,//5
  xboref, //6
  xbapic,//7
  xbapic2,//8
  xba2pic2,//9
  xba2pic,//10
  xbaref,//11
  xbnpic,//12
  xbnpic2,//13
  xbn2pic2,//14
  xbn2pic,//15
  xbnref, //16
  xl1, //17
  xl2, //18
  xl3,//19
  xl4,//20
  xl5,//21
  xl6,//22
  xwt, //23
  xwf,//24
  xlt,//25
  xlf,//26
  init1, //27
  init2,  //28
  xpage, //29
  xt1, //30
  xt2, //31
  xt3,//32
  xt4,//33
  xt5,  //34
  xt6,  //35
  xt7,  //36
  xgt1, //37
  xgt2, //38
  xgt3,//39
  xgt4,//40
  xgt5,//41
  xgt6,  //42
  xgt7,  //43
  xgt8,  //44
  xgt9,  //45
  xgt10,  //46
  xt7,  //47
  xt8,  //48 
  xt10  //49



};



char const  xon[] PROGMEM = "ON";
char const  xoff[] PROGMEM = "OFF";
char const  xnight[] PROGMEM = "NIGHT";
char const  xsunrise[] PROGMEM = "SUNRISE";
char const  xsunset[] PROGMEM = "SUNSET";
char const  xdash[] PROGMEM = "-";

char const xcelc[]  = "'C";
char const xpercent[]  = "%";

PGM_P const nxConstStrings[] PROGMEM
{
  xon, //0
  xoff, //1
  xnight, //2
  xsunrise, //3
  xsunset, //4
  xdash //5
};

